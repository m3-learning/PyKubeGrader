OK_FORMAT = True

test = {   'name': 'avengers-mission-modules',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> from pykubegrader.telemetry import ensure_responses, log_variable, score_question, submit_question, telemetry, update_responses\n'
                                               '>>> import os\n'
                                               '>>> import base64\n'
                                               '>>> import matplotlib\n'
                                               '>>> import matplotlib\n'
                                               '>>> max_question_points = str(3.0)\n'
                                               '>>> earned_points = 0\n'
                                               ">>> os.environ['EARNED_POINTS'] = str(earned_points)\n"
                                               ">>> os.environ['TOTAL_POINTS_FREE_RESPONSE'] = str(3.0)\n"
                                               ">>> log_variable('total-points', f'week999-readings, 13_module_q', 3.0)\n"
                                               ">>> question_id = 'avengers-mission-modules-1'\n"
                                               '>>> max_score = 1.0\n'
                                               '>>> score = 0\n'
                                               ">>> matplotlib.use('Agg')\n"
                                               '>>> hammer_area, _, _ = avengers_assemble()\n'
                                               '>>> assert math.isclose(hammer_area, 314.159, rel_tol=0.001), "Thor\'s hammer area calculation is incorrect."\n'
                                               '>>> if math.isclose(hammer_area, 314.159, rel_tol=0.001):\n'
                                               '...     score = 1.0\n'
                                               ">>> earned_points = float(os.environ.get('EARNED_POINTS', 0))\n"
                                               '>>> earned_points += score\n'
                                               ">>> log_variable('13_module_q', f'{score}, {max_score}', question_id)\n"
                                               ">>> os.environ['EARNED_POINTS'] = str(earned_points)\n",
                                       'failure_message': "Thor's hammer area calculation is incorrect.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': "Correctly calculated Thor's hammer area."},
                                   {   'code': '>>> from pykubegrader.telemetry import ensure_responses, log_variable, score_question, submit_question, telemetry, update_responses\n'
                                               '>>> import os\n'
                                               '>>> import base64\n'
                                               '>>> import matplotlib\n'
                                               '>>> import matplotlib\n'
                                               ">>> question_id = 'avengers-mission-modules-2'\n"
                                               '>>> max_score = 1.0\n'
                                               '>>> score = 0\n'
                                               ">>> matplotlib.use('Agg')\n"
                                               '>>> _, iron_cosine, _ = avengers_assemble()\n'
                                               '>>> assert math.isclose(iron_cosine, 0.707, rel_tol=0.001), "Iron Man\'s cosine calculation is incorrect."\n'
                                               '>>> if math.isclose(iron_cosine, 0.707, rel_tol=0.001):\n'
                                               '...     score = 1.0\n'
                                               ">>> earned_points = float(os.environ.get('EARNED_POINTS', 0))\n"
                                               '>>> earned_points += score\n'
                                               ">>> log_variable('13_module_q', f'{score}, {max_score}', question_id)\n"
                                               ">>> os.environ['EARNED_POINTS'] = str(earned_points)\n",
                                       'failure_message': "Iron Man's cosine calculation is incorrect.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': "Correctly calculated Iron Man's cosine of 45 degrees."},
                                   {   'code': '>>> from pykubegrader.telemetry import ensure_responses, log_variable, score_question, submit_question, telemetry, update_responses\n'
                                               '>>> import os\n'
                                               '>>> import base64\n'
                                               '>>> import matplotlib\n'
                                               '>>> import matplotlib\n'
                                               ">>> question_id = 'avengers-mission-modules-3'\n"
                                               '>>> max_score = 1.0\n'
                                               '>>> score = 0\n'
                                               ">>> matplotlib.use('Agg')\n"
                                               '>>> _, _, cap_lcm = avengers_assemble()\n'
                                               '>>> assert cap_lcm == 36, "Captain America\'s LCM calculation is incorrect."\n'
                                               '>>> if cap_lcm == 36:\n'
                                               '...     score = 1.0\n'
                                               ">>> earned_points = float(os.environ.get('EARNED_POINTS', 0))\n"
                                               '>>> earned_points += score\n'
                                               ">>> log_variable('13_module_q', f'{score}, {max_score}', question_id)\n"
                                               ">>> os.environ['EARNED_POINTS'] = str(earned_points)\n",
                                       'failure_message': "Captain America's LCM calculation is incorrect.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': "Correctly calculated Captain America's LCM."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
